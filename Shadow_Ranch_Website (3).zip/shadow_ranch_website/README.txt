SHADOW RANCH WEBSITE

1. Entpacke den Ordner.
2. Öffne index.html im Browser, um die Website zu testen.
3. Lade index.html und den Ordner assets auf deinen Webspace hoch.
4. Für eine echte Online-Bewerbung kann später ein Discord-Webhook, Formularserver oder MDT angebunden werden.

Die Bilder liegen bereits im assets-Ordner.
